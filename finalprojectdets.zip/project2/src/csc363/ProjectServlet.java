package csc363;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/ProjectServlet")
public class ProjectServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProjectServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		product[] myProducts = getProductsOnSale();
		
		processRequestAndRespond(request, response, myProducts);
	
		
	}

	/**
	 * @param request
	 * @param response
	 * @param myProducts
	 * @throws ServletException
	 * @throws IOException
	 */
	private void processRequestAndRespond(HttpServletRequest request, HttpServletResponse response,
			product[] myProducts) throws ServletException, IOException {
		
		String forwardingPage = "./Project.jsp";
		HttpSession mySession = request.getSession();
		mySession.setAttribute("Products", myProducts);
		String pName = (String)request.getParameter("uname");
		mySession.setAttribute("UserName", pName);

		
		request.getRequestDispatcher(forwardingPage).forward(request, response);
	
	}
	
	
	

	/**
	 * @return
	 */
	private product[] getProductsOnSale() {
		product[] myProducts = new product[1];
		Connection conn = null;
		try {
		    Class.forName("com.mysql.jdbc.Driver");
		} catch(ClassNotFoundException e) {
		    e.printStackTrace();
		}

		try {
		    conn =
		       DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/project","root", "vmdb");
		    
		    
		    Statement countstmt = conn.createStatement();
		    countstmt.setFetchSize(100);
		    ResultSet rscount = countstmt.executeQuery("SELECT COUNT(*) as arrayLength FROM project.motherboard");
		    
		    while (rscount.next()) {
		    	myProducts = new product[rscount.getInt("arrayLength")];
		    }
		    
		    
		    Statement stmt = conn.createStatement();
		    stmt.setFetchSize(100);
		    ResultSet rs = stmt.executeQuery("SELECT * FROM motherboard");
		    int i=0;
		    while (rs.next()) {
		    	
		    	int pProductID = rs.getInt(1);
		    	String pProductName = rs.getString(2);
		    	String pProductImagePath = rs.getString(3);
		    	double pProductCost = rs.getDouble(4);
		    	String pGen = rs.getString(5);
		    	String pRam = rs.getString(6);
		    	String pAudio = rs.getString(7);
		    	product p1= new product();
				p1.setMfgName(pProductName);
				p1.setImagePath(pProductImagePath);
				p1.setCost(pProductCost);
				p1.setGen(pGen);
				p1.setRam(pRam);
				p1.setAudio(pAudio);
				p1.setproductId(pProductID);
				myProducts[i] = p1;
				i++;
				

            }

            rs.close();
            rs = null;

            stmt.close();
            stmt = null;

            //conn.commit();
            conn.close();
            conn = null;

		
		} catch (SQLException ex) {
		    // handle any errors
		    System.out.println("SQLException: " + ex.getMessage());
		    System.out.println("SQLState: " + ex.getSQLState());
		    System.out.println("VendorError: " + ex.getErrorCode());
		}
		return myProducts;
		
		
	}

	
	private product[] getProduct(int item) {
		product[] selectProduct = new product[1];
		product[] myProducts = getProductsOnSale();
		selectProduct[0]=myProducts[item];
		return selectProduct;
	}
	
	
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String forwardingPage = "./index.jsp";
	
		
		doGet(request, response);
	}

}
