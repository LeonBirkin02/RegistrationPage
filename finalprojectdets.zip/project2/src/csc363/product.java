package csc363;

import java.io.Serializable;

import javax.servlet.http.HttpSession;

public class product implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String MfgName;
	private String ImagePath;
	private double Cost;
	private String Gen;
	private int productId;
	private String Ram;
	private String Audio;
	 
	public String getMfgName() {
		return MfgName;
	}
	public void setMfgName(String mfgName) {
		MfgName = mfgName;
	}
	public String getImagePath() {
		return ImagePath;
	}
	public void setImagePath(String imagePath) {
		ImagePath = imagePath;
	}
	public double getCost() {
		return Cost;
	}
	public void setCost(double cost) {
		Cost = cost;
	}
	
	
	public String getGen() {
		return Gen;
	}
	public void setGen(String gen) {
		Gen =gen;
	}
	
	public String getRam() {
		return Ram;
	}
	public void setRam(String ram) {
		Ram = ram;
	}
	
	public String getAudio() {
		return Audio;
	}
	public void setAudio(String audio) {
		Audio = audio;
	}
	
	public int getproductId() {
		return productId;
	}
	public void setproductId(int pid) {
		productId = pid;
	}

}
